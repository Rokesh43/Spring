package ioc;

public class Student {
	private String rollnumber;
	private String name;
	private String sclass;
	public Student(String rollnumber, String name, String sclass) {
		
		this.rollnumber = rollnumber;
		this.name = name;
		this.sclass = sclass;
	}
	@Override
	public String toString() {
		return "Student [rollnumber=" + rollnumber + ", name=" + name + ", sclass=" + sclass + "]";
	}
	
	
	
	

}
