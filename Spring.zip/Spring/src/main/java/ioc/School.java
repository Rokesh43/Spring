package ioc;

public class School {
	
	private String name;
	private String loc;
	private Student student;
	public School(String name, String loc, Student student) {
		super();
		this.name = name;
		this.loc = loc;
		this.student = student;
	}
	
	@Override
	public String toString() {
		return "School [name=" + name + ", loc=" + loc + ", student=" + student + "]";
	}
	

}
