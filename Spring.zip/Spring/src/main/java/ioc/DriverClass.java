package ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DriverClass {
	public static void main(String[] args) {
	
		ApplicationContext context=new ClassPathXmlApplicationContext("student.xml");
		
		School s=(School)context.getBean("s1");
		
		System.out.println(s);
		
	}

}
