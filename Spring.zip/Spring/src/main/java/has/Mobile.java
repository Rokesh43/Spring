package has;

public class Mobile {
	private String brand,model;
	private double price;
	private SimCard simcard;
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public SimCard getSimcard() {
		return simcard;
	}
	public void setSimcard(SimCard simcard) {
		this.simcard = simcard;
	}
	@Override
	public String toString() {
		return "Mobile [brand=" + brand + ", model=" + model + ", price=" + price + ", simcard=" + simcard + "]";
	}
	

}
