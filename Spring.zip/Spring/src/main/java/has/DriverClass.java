package has;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DriverClass {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("simcard.xml");
		
		Mobile m=(Mobile)context.getBean("m1");
		
		System.out.println(m);
		
		
	}

}
