package has;

public class SimCard {
	private long simno;
	private String networkprovider;
	private int plan;
	public long getSimno() {
		return simno;
	}
	public void setSimno(long simno) {
		this.simno = simno;
	}
	public String getNetworkprovider() {
		return networkprovider;
	}
	public void setNetworkprovider(String networkprovider) {
		this.networkprovider = networkprovider;
	}
	public int getPlan() {
		return plan;
	}
	public void setPlan(int plan) {
		this.plan = plan;
	}
	@Override
	public String toString() {
		return "SimCard [simno=" + simno + ", networkprovider=" + networkprovider + ", plan=" + plan + "]";
	}
	
	

}
