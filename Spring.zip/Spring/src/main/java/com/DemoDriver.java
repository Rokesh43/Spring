package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class DemoDriver {
	public static void main(String[] args) {
		// core container
		
//		Resource res=new ClassPathResource("config.xml");
//		BeanFactory bf=new XmlBeanFactory(res);
//		Demo d=(Demo)bf.getBean("Advjava");
//		
//		d.teach();
		
		
		//J2EE container
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("config.xml");
		Demo d=(Demo)ac.getBean("Advjava");
		d.teach();
	}

}
