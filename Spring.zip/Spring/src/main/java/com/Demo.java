package com;

public class Demo {
	
	public void teach() {
		System.out.println("Teach Spring");
	}

}
