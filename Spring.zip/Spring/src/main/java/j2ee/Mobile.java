package j2ee;

public class Mobile {
	
	public void using() {
		System.out.println("Student are using mobile");
	}

}
