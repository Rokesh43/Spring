package j2ee;

import java.net.CacheRequest;

import javax.swing.text.html.HTMLDocument.HTMLReader.CharacterAction;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class StudentDriver {
	public static void main(String[] args) {
		ConfigurableApplicationContext cac= new ClassPathXmlApplicationContext("student.xml");
		
		Student s=(Student) cac.getBean("stu");
		
		s.play();
		
		System.out.println(s.getName());
		
		System.out.println(s.getAge());
		
		Mobile m=s.getMob();
		
		m.using();
	}

}
