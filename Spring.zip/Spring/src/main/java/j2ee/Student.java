package j2ee;

public class Student {
	
	private String name;
	private int age;
	private Mobile mob;
	
	public Mobile getMob() {
		return mob;
	}

	public void setMob(Mobile mob) {
		this.mob = mob;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void play() {
		System.out.println("Students are Playing the game");
	}

}
