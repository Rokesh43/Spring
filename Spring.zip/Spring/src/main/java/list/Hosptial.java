package list;

import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Hosptial {
	private String name;
	private String loc;
	private Set<String> patient;
	public Hosptial(String name, String loc, Set<String> patient) {
		super();
		this.name = name;
		this.loc = loc;
		this.patient = patient;
	}
	@Override
	public String toString() {
		return "Hspital [name=" + name + ", loc=" + loc + ", patient=" + patient + "]";
	}
	
	public static void main(String[] args) {
ApplicationContext context=new ClassPathXmlApplicationContext("Hospital.xml");
		
		Hosptial c=(Hosptial)context.getBean("h1");
		
		System.out.println(c);
		
	}
	
	

}
