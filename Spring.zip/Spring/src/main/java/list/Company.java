package list;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Company {
	private int cid;
	private String name;
	private String loc;
	
	private List<String> employee;
	
	

	public Company(int cid, String name, String loc, List<String> employee) {
		super();
		this.cid = cid;
		this.name = name;
		this.loc = loc;
		this.employee = employee;
	}



	@Override
	public String toString() {
		return "Company [cid=" + cid + ", name=" + name + ", loc=" + loc + ", employee=" + employee + "]";
	}
	
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("company.xml");
		
		Company c=(Company)context.getBean("c1");
		
		System.out.println(c);
	}
	
	
	

}
