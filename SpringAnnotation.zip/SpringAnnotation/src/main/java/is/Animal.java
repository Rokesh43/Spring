package is;

public interface Animal {
	void sound();

}
