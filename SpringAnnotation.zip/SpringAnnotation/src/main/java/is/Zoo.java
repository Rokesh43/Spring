package is;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("z")
public class Zoo {
	@Autowired
	@Qualifier("pig")
	private Animal a1;
	
	
	@Autowired
	@Qualifier("donkey")
	private Animal a2;
	
	public void getAnimalSound() {
		a1.sound();
		a2.sound();
	}

}
