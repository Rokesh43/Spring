package is;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("p")
@Qualifier("pig")
public class Pig implements Animal {

	@Override
	public void sound() {
		System.out.println("pig grunts");
		
	}

}
