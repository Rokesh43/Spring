package is;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Qualifier("donkey")
public class Donkey implements Animal{

	@Override
	public void sound() {
		System.out.println("Donkey makes hee-haw");
		
	}
	

}
