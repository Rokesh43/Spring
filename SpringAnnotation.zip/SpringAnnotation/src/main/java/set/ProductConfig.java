package set;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class ProductConfig {
	
	
	@Bean
	@Qualifier("brand")
	public Set<String> m1(){
		HashSet<String> hs=new HashSet();
		
		hs.add("BMW");
		hs.add("Audi");
		hs.add("Mahindra");
		hs.add("Verna");
		hs.add("Honda");
		
		return hs;
		
	}
	@Bean
	@Qualifier("color")
	public Set<String> m2(){
		HashSet<String> hs=new HashSet();
		
		hs.add("Black");
		hs.add("Green");
		hs.add("Blue");
		hs.add("White");
		hs.add("Red");
		
		return hs;
		
	}
	
	}
