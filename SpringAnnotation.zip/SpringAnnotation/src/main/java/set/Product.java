package set;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("p")
public class Product {
	@Value("1")
	private int productId;
	@Autowired
	@Qualifier("brand")
	private Set<String> brand;
	@Autowired
	@Qualifier("color")
	private Set<String> color;
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", brand=" + brand + ", color=" + color + "]";
	}
	
	
	

}
