package set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import list.Company;
import list.CompanyConfig;

public class DriverClass {
	public static void main(String[] args) {
ApplicationContext context=new AnnotationConfigApplicationContext(ProductConfig.class);
		
		Product p=(Product)context.getBean("p");
		
		System.out.println(p);
	}

}
