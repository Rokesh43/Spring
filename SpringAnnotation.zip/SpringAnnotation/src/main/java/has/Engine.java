package has;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("e")
public class Engine {
	
	@Value("1500cc")
	private String cc;
	@Value("petrol")
	private String type;
	@Value("123VHAF54")
	private String engineNo;
	@Value("v1")
	private String version;
	@Override
	public String toString() {
		return "Engine [cc=" + cc + ", type=" + type + ", engineNo=" + engineNo + ", version=" + version + "]";
	}
	
	
	

}
