package has;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("c")
public class Car {
	@Value("BMW")
	private String brand;
	@Value("X1")
	private String model;
	@Value("Black")
	private String color;
	@Value("1500000")
	private double price;
	
	@Autowired
	private Engine engine;

	@Override
	public String toString() {
		return "Car [brand=" + brand + ", model=" + model + ", color=" + color + ", price=" + price + ", engine="
				+ engine + "]";
	}

	
	

}
