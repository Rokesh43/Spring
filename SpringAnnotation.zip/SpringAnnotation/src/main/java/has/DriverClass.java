package has;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class DriverClass {
	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(CarConfig.class);
		Car c=(Car)context.getBean("c");
		System.out.println(c);
	}

}
