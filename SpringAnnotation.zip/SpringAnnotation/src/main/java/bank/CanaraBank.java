package bank;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("c")
@Primary
public class CanaraBank implements Bank{

	@Override
	public void getBalance() {
		System.out.println("Canara Bank Balance :4000");
		
	}

}
