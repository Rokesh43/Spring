package bank;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class DriverClass {
	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(BankConfig.class);
		
		User u=(User)context.getBean("u");
		
		u.getBankBalance();
	}

}
