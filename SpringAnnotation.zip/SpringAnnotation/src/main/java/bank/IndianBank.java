package bank;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("i")

public class IndianBank implements Bank{

	@Override
	public void getBalance() {
		System.out.println("Indian Bank Balance : 5000");
		
	}
	

}
