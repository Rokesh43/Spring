package bank;

public interface Bank {
	void getBalance();

}
