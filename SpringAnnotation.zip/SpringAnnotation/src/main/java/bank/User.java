package bank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("u")
public class User {
	
	@Autowired
	Bank bank;
	
	void getBankBalance() {
		bank.getBalance();
	}
	

}
