package in;

import org.springframework.stereotype.Component;

@Component("s")
public class Student {
	Student(){
		System.out.println("Constructor call");
	}
	
	public void m1() {
		System.out.println("Hello world");
	}

}
