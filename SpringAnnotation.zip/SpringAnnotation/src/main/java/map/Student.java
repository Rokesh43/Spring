package map;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("s")
public class Student {
	@Value("Rokesh")
	private String name;
	@Value("6369379834")
	private long phone;
	@Autowired
	
	private Map<String,Double> marks;
	@Override
	public String toString() {
		return "Student [name=" + name + ", phone=" + phone + ", marks=" + marks + "]";
	}
	
	

}
