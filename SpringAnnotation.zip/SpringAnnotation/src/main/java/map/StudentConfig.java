package map;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class StudentConfig {
	
	@Bean
	public Map<String, Double> m1(){
		HashMap<String , Double> hm=new HashMap<String, Double>();
		
		hm.put("Tamil", 82.0);
		hm.put("Engilsh", 75.5);
		hm.put("Maths", 98.2);
		hm.put("Science", 84.3);
		hm.put("Social science", 92.3);
		
		return hm;
	}

}
