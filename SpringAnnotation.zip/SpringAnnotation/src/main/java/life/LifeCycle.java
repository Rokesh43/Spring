package life;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.Lifecycle;
import org.springframework.stereotype.Component;

@Component("l")
public class LifeCycle {
	
	@Autowired
	private Demo d;
	LifeCycle(){
		System.out.println("Object is Created");
	}
	
	public void getObject() {
		System.out.println(d!=null?"Dependencies Injected":"Dependencies not injected");
	}
	
	@PostConstruct
	public void m1() {
		System.out.println("This is init method");
	}
	
	@PreDestroy
	public void m2() {
		System.out.println("This is destroy method");
	}
	
	public void save() {
		System.out.println("This save method");
	}

}
