package life;

import org.springframework.stereotype.Component;

@Component("d")
public class Demo {

}
