package list;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class CompanyConfig {
	
	@Bean
	@Qualifier("l1")
	public List<String> m1(){
		ArrayList<String> al=new ArrayList<String>();
		
		al.add("Rokesh");
		al.add("Dharun");
		al.add("Sharvin");
		al.add("Selva");
		
		return al;
	}
	
	@Bean
	@Qualifier("l2")
	public List<String> m2(){
		ArrayList<String> al=new ArrayList<String>();
		
		al.add("Samantha");
		al.add("Sakila");
		al.add("selva");
		al.add("sharvin");
		
		return al;
	}

}
