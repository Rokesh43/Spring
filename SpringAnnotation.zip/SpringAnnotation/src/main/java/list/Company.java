package list;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("c")
public class Company {
	@Value("1")
	private int id;
	@Value("TCS")
	private String name;
	@Value("Chennai")
	private String loc;
	@Value("9835428645")
	private long phone;
	
	@Autowired
	@Qualifier("l1")
	private List<String> employees1;
	
	
	@Autowired
	@Qualifier("l2")
	private List<String> employees2;


	@Override
	public String toString() {
		return "Company [id=" + id + ", name=" + name + ", loc=" + loc + ", phone=" + phone + ", employees1="
				+ employees1 + ", employees2=" + employees2 + "]";
	}
	
	
	

}
