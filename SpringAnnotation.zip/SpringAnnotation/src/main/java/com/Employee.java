package com;

import org.springframework.stereotype.Component;

@Component("e")
public class Employee {
	Employee(){
		System.out.println("Constructed call");
	}
	
	public  void m1() {
		System.out.println("This is m1 method");
	}
	

}
